import java.util.ArrayList;
import java.util.Iterator;

public class Club {
    private ArrayList<Membership> clubMembers;
  
    public Club() {
        clubMembers = new ArrayList<Membership>();
    }


    public void join(Membership member) {
        if (search(member.getName()) == 0) {
            clubMembers.add(member);
            System.out.println(member.getName() + " adicionado/a ao clube.");
        }
        
        else {
            System.out.println(member.getName() + " já é membro/a do clube.");
        }
    }

    public int numberOfMembers() {
        return clubMembers.size();
    }

    public void numberJoinedInMonth(int month, int year) {
        if (month >= 1 && month <= 12) {
            int membersJoined = 0;

            for (Membership member : clubMembers) {
                if (month == member.getMonth() && year == member.getYear()) {
                    membersJoined++;
                }
            }
            System.out.println(membersJoined + " juntaram-se ao clube no mês " + month + "º mês do ano " + year);
        } 
        
        else {
            System.out.println("Não é um mês válido.");
        }

    }

    public void listJoinedInMonth(int month, int year) {
        if (month >= 1 && month <= 12) {

            for (Membership member : clubMembers) {
                if (month == member.getMonth() && year == member.getYear()) {
                    System.out.println(member.getName());
                }
            }
        } 
        
        else {
            System.out.println("Não é um mês válido.");
        }

    }

    public int search(String nomeSearch) {
        int soma = 0;
        for (Membership member : clubMembers) {
            if (nomeSearch.equals(member.getName())) {
                soma++;
            }
        }
        System.out.println(soma + " correspondência(s) encontradas para " + nomeSearch + ".");
        return soma;
    }


    public void remove(String nomeSearch) {
        
        Iterator<Membership> it = clubMembers.iterator();
        int var = 0;
        
        while (it.hasNext()) {
            Membership member = it.next();
            if (member.getName().toLowerCase().equals(nomeSearch.toLowerCase())) {
                it.remove();
                var++;
            }
        }
        
        System.out.println(var + " correspondência(s) encontradas para " + nomeSearch + " e removidas da lista.");
    }
}
