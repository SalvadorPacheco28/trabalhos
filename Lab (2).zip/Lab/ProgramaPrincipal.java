public class ProgramaPrincipal {
  public static void main(String[] args) {
   
    Club club;
    club = new Club();

    club.join(new Membership("Rendrick", 7, 2000));
    club.join(new Membership("David", 5, 2001));
    club.join(new Membership("Ribeiro", 3, 2003));

    System.out.println("O clube possui " + club.numberOfMembers() + " elementos.");


  }
}