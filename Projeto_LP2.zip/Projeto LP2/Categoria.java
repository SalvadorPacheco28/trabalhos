enum Categoria {
    R, /* Regular */
    E, /* Estrela */
    P, /* Promessa */
    NA; /* Não Definido */
}
