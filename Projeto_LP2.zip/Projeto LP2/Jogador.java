import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Year;

import javax.xml.crypto.Data;
import java.util.ArrayList;

public class Jogador implements Liga,Taca{  /* <--- Implementar as Interfaces Liga e Taca */
    private String NomeJ;
    private int ID;
    private LocalDate DataEntrada;
    private Posicao posicao;
    private double salario;
    private Categoria categoria;
    private static int increment = 0;
    private int JogosJogados; 
    
    /* Construtor */
    public Jogador(String NomeJ, LocalDate DataEntrada, Categoria categoria, Posicao posicao){
        if(NomeJ == null){
            this.NomeJ = "";                        ///////////////////
        }                                           //  Verificação //
        else{                                       /////////////////
            this.NomeJ = NomeJ;
        }
        this.ID = ++increment;
        if(DataEntrada != null){
            this.DataEntrada = DataEntrada;}
        else{
            this.DataEntrada = LocalDate.now();
        }
        if(categoria == null){
            this.categoria = Categoria.NA;}
        else{ 
            this.categoria = categoria;  
        }
        if(posicao == null){
            this.posicao = Posicao.NA;}
        else{
            this.posicao = posicao;
        }
        if(JogosJogados > 0){
            this.JogosJogados = JogosJogados;
        }
        else{
            this.JogosJogados = 0;
        }
        }

    /*----------------------------------- /Sets e Gets/ ------------------------------------------------- */    
    public void setNome(String NomeJ){
        this.NomeJ = NomeJ;
    }
    public String getNome(){
        return NomeJ;
    }
    public int getID(){
        return ID;
    }
    public void setDataEntrada(LocalDate DataEntrada){
        this.DataEntrada = DataEntrada;
    }
    public LocalDate getDataEntrada(){
        return DataEntrada;
    }
    public void setPosicao(Posicao posicao){
        this.posicao = posicao;
    }
    public Posicao getPosicao(){
        return posicao;
    }
    public void setSalario(double salario){
        this.salario = salario;
    }
    public double getSalario(){
        return salario;
    }
    public void setCategoria(Categoria categoria){
        this.categoria = categoria;
    }
    public Categoria getCategoria(){
        return categoria;
    }
    public void setJogosJogados(int JogosJogados){
        this.JogosJogados = JogosJogados;
    }
    public int getJogosJogados(){
        return JogosJogados;
    }
/*----------------------------------- /Sets e Gets/ ------------------------------------------------- */

    /* Ficha de Jogador */
    public String toString(){
        return ("Ficha:" + "\n"+ "Nome: " + NomeJ + "\n" + "Codigo do Jogador: " + ID + "\n" + "Posição: " + posicao + "\n" + "Categoria: " + categoria + "\n" + "Salário: " + getVencimento());
    }
    
    /*Aumento do Salario dos Jogadores pelas classes */
    public double getVencimento(){
        if (categoria == Categoria.R){
            salario = 1500;
            salario = salario + (salario * 0.05);    /* <--- Bónus se o Jogador for Regular */
        }
        else if(categoria == Categoria.E){           /* <--- Bónus se o Jogador for Estrela */
            salario = 1500;
            salario = salario + (salario * 0.15);
        }

        return salario;
    }

    public static void add(Jogador e) {
    }

    public static Jogador valueOf(String nextLine) {
        return null;
    }
}



