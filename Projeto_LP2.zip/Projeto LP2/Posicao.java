enum Posicao { /* Enumerador com as variáveis do Tipo da Posição */
    GR, /* Guarda Redes */
    D, /* Defesa */
    M, /* Médio */
    A, /* Atacante */
    NA; /* Não Definido */
}
