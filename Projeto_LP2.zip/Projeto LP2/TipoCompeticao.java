enum TipoCompeticao { /* Enumerador com as variáveis do Tipo de Competição */
    Liga,
    Taca,
    NA; /* <-- Não definido */
}
