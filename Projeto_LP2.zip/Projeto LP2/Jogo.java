import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;

public class Jogo implements Liga,Taca{     /* Classe Jogo implementa as interfaces Liga e Taca */
    private int Convocados;
    enum TipoCompeticao{Liga,Taca,NA};
    private TipoCompeticao tipoCompeticao;
    private LocalDate DataDoJogo;
    private String clubeEquipa;
    private String Adversário;
    private int ResultadoClube;
    private int ResultadoAdversário;
    enum Vencedor{clubeEquipa,Adversário,Empate};
    private Vencedor vencedor;
    private static int increment = 0;
    private int W = 0;
    private int D = 0;
    private int L = 0;
    private static int incrementer = 0;
    private LocalJogo Local;
    private ArrayList<Jogador> EquipaLiga;
    private ArrayList<Jogador> EquipaAdversário;
    private Jogador MVP;

/* Construtor */
public Jogo(String clubeEquipa, String Adversário, int ResultadoClube, int ResultadoAdversário, Vencedor vencedor, LocalDate DataDoJogo, LocalJogo Local, TipoCompeticao tipoCompeticao){
    if(clubeEquipa == null){
        this.clubeEquipa = "";                      ///////////////////
    }                                               //  Verificação //
    else{                                           ///////////////////
        this.clubeEquipa = clubeEquipa;
    }
    if(Adversário == null){
        this.Adversário = "";
    }
    else{
        this.Adversário = Adversário;
    }
    if(tipoCompeticao == null){
        this.tipoCompeticao = TipoCompeticao.NA;
    }
    else{
        this.tipoCompeticao = tipoCompeticao;
    }
    this.ResultadoClube = ResultadoClube;
    this.ResultadoAdversário = ResultadoAdversário;
    if(Local == null){
        this.Local = LocalJogo.NA;}
    else{ 
        this.Local = Local;  
    }
    if(DataDoJogo != null){
        this.DataDoJogo = DataDoJogo;}
    else{
        this.DataDoJogo = LocalDate.now();
    }
    }

/*----------------------------------------------- /Sets e Gets/ ------------------------------------------------------- */

public void setConvocados(int Convocados){
    this.Convocados = Convocados;
}
public int getConvocados(){
    return Convocados;
}
public void setTipoCompeticao(TipoCompeticao tipoCompeticao){
    this.tipoCompeticao = tipoCompeticao;
}
public TipoCompeticao getTipoCompeticao(){
    return tipoCompeticao;
}
public void setDataDoJogo(LocalDate DataDoJogo){
    this.DataDoJogo = DataDoJogo;
}
public LocalDate getDataDoJogo(){
    return DataDoJogo;    
}
public void setClubeEquipa(String clubeEquipa){
    this.clubeEquipa = clubeEquipa;
}
public String getClubeEquipa(){
    return clubeEquipa;
}
public void setAdversário(String Adversário){
    this.Adversário = Adversário;
}
public String getAdversário(){
    return Adversário;
}
public void setResultadoClube(int ResultadoClube){
    this.ResultadoClube = ResultadoClube;
}
public int getResultadoClube(){
    return ResultadoClube;
}
public void setResultadoAdversário(int ResultadoAdversário){
    this.ResultadoAdversário = ResultadoAdversário;
}
public int getResultadoAdversário(){
    return ResultadoAdversário;
}
public int getWin(){
    if(ResultadoClube > ResultadoAdversário){
        W = ++incrementer;
    }
    return W;
}
public int getDraw(){
    if(ResultadoClube == ResultadoAdversário){
        D = ++incrementer;
    }
    return D;
}
public int getLoss(){
    if(ResultadoClube < ResultadoAdversário){
        L = ++ incrementer;
    }
    return L;
}
public void setLocal(LocalJogo Local){
    this.Local = Local;
}
public LocalJogo getLocal(){
    return Local;
}

/*----------------------------------------------- /Sets e Gets/ ------------------------------------------------------- */

/*Dados do jogo */
public String toString(){

    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    
    return "\n" + dateFormat.format(new Date()) + ":\n" +
            "Tipo de Competição:" + tipoCompeticao + "\n" +
            "Local do Jogo" + Local + "\n" +
            "Equipa 1:" + clubeEquipa + "\n" +
            "Equipa 2:" + Adversário + "\n" +
            "Resultado:" + ResultadoClube + "-" + ResultadoAdversário +"\n";
}

/* Caclular o Vencedor do Jogo a partir dos Resultados das Equipas */
public Vencedor calcularVencedor() {
    if (ResultadoClube > ResultadoAdversário)   
        vencedor = Vencedor.clubeEquipa;
    else if (ResultadoClube < ResultadoAdversário)
        vencedor = Vencedor.Adversário;
    else
        vencedor = Vencedor.Empate;
    return vencedor;
}
}
