import javax.swing.event.SwingPropertyChangeSupport;

public interface Liga { /* Interface implementada no Jogo */
    
    /*Super dos atributos da classe Jogo */
    super(Convocados, DataDoJogo, Adversário, Clube, vencedor);

    for(int Convocados=0; Convocados>=11; Convocados++){
        System.out.println(Convocados);
    }
}
