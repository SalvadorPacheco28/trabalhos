public interface Taca {  /* Interface implementada no Jogo */ 
    
    /*Super dos atributos da classe Jogo */
    super(Convocados,Casa, Fora, DataDoJogo, Adversário, Clube);

for(int Convocados=0; Convocados>=13; Convocados++){
    System.out.println(Convocados);
}

}
