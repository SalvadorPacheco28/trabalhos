enum LocalJogo { /* Enumerador com as variáveis do Local do Jogo */
    FORA,
    CASA,
    NA;       /* <-- Não definido */
}
