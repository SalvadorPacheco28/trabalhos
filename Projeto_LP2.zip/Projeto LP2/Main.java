import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;


public class Main {
    
    public static void main(String[] args) {
        menuPrincipal();
    }
    
    /* Menu Principal */
    public static void menuPrincipal(){
        
        /* Scanner para realizar o input do utilizador */
        Scanner menu = new Scanner (System.in);

        System.out.print("##------ Menu Principal ----##|\n");
        System.out.print("|-----------------------------|\n");
        System.out.print("| Opção 1 - Jogador           |\n");
        System.out.print("| Opção 2 - Clube             |\n");
        System.out.print("| Opção 3 - Jogo              |\n");
        System.out.print("| Opção 4 - Sair              |\n");
        System.out.print("|-----------------------------|\n");
        System.out.print("Digite uma opção: ");

        int opcao = menu.nextInt();

        /*Inserir opções */
        switch (opcao) {
        case 1:
            menuJogador();    /* <-- Voltar ao Menu Jogador */
            break;
        case 2:
            menuClube();      /* <-- Voltar ao Menu Clube */
            break;
        case 3:
            menuJogo();       /* <-- Voltar ao Menu Jogo */
            break;
        case 4:
            System.out.print("\n Até logo! \n");
            menu.close();
        }   
    }
/* --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- */       

/* Menu do Jogo */
private static void menuJogo(){
    
    /* Array List dos Jogadores dentro da Equipa do Clube*/
    ArrayList<Jogador> equipaLiga = new ArrayList<Jogador>();
    
    /* Array List dos Jogadores dentro da Equipa Adversária*/
    ArrayList<Jogador> equipaAdversario = new ArrayList<Jogador>();
    
    /* Scanner para realizar o input do utilizador */
    Scanner scanner = new Scanner(System.in);
    Jogo jogo = new Jogo("", "", 0, 0, Jogo.Vencedor.Empate, LocalDate.now(), LocalJogo.NA, Jogo.TipoCompeticao.NA);

        while (true) {
            System.out.print("##------------------- Menu Jogo ------------------##|\n");
            System.out.print("|---------------------------------------------------|\n");
            System.out.print("| Opção 1 - Inserir informação do Jogo              |\n");
            System.out.print("| Opção 2 - Adicionar jogadores à equipa da Liga    |\n");
            System.out.print("| Opção 3 - Adicionar jogadores à equipa adversária |\n");
            System.out.print("| Opção 4 - Ver informação do jogo                  |\n");
            System.out.print("| Opção 5 - Sair                                    |\n");
            System.out.print("|---------------------------------------------------|\n");
            System.out.print("Digite uma opção: ");

            int opcao = scanner.nextInt();
            scanner.nextLine();

            /*Inserir opções */
            if (opcao == 1) {
                
                /* Inserir informação do Jogo  */
                System.out.print("Clube da equipa: ");
                String clubeEquipa = scanner.nextLine();
                
                System.out.print("Adversário: ");
                String adversario = scanner.nextLine();
                
                System.out.print("Resultado clube: ");
                int resultadoClube = scanner.nextInt();
                
                System.out.print("Resultado adversário: ");
                int resultadoAdversario = scanner.nextInt();
                scanner.nextLine();
                
                System.out.print("Data do jogo (yyyy-MM-dd): ");
                LocalDate dataDoJogo = LocalDate.parse(scanner.nextLine());
                
                System.out.print("Local do jogo: ");
                String localJogo = scanner.nextLine();
                
                System.out.print("Tipo de competição: ");
                String tipoCompeticao = scanner.nextLine();

                jogo.setClubeEquipa(clubeEquipa);
                jogo.setAdversário(adversario);
                jogo.setResultadoClube(resultadoClube);
                jogo.setResultadoAdversário(resultadoAdversario);
                jogo.setDataDoJogo(dataDoJogo);
                jogo.setLocal(LocalJogo.valueOf(localJogo.toUpperCase()));
                jogo.setTipoCompeticao(Jogo.TipoCompeticao.valueOf(tipoCompeticao));
                jogo.calcularVencedor();
                
                /*Adicionar jogadores à equipa */
                } else if (opcao == 2) {
                System.out.print("Nome do jogador: ");
                String nome = scanner.nextLine();
                
                System.out.print("Posição (GR,D,M,A,): ");
                Posicao posicao = Posicao.valueOf(scanner.nextLine());
                
                System.out.println("Insina o Ano de entrada no Clube:  ");
                int y = scanner.nextInt();
                System.out.println("Insira o Mês de entrada no Clube: ");
                int m = scanner.nextInt();
                System.out.println("Insira o Dia de entrada do Clube: ");
                int d = scanner.nextInt();
                LocalDate DataEntrada = LocalDate.of(y, m, d);
                scanner.nextLine();
                
                System.out.print("\n Inserir a Categoria (R/E/P/NA): ");
                Categoria categoria =  Categoria.valueOf(scanner.nextLine());
		
        Jogador jogador = new Jogador(nome, DataEntrada, categoria, posicao );
		if (equipaLiga.size() < 11) {
		equipaLiga.add(jogador);
	    } else {
		System.out.println("Não se pode adicionar mais jogadores ao plantel da equipa da Liga");
	}   
        /* Adicionar jogadores à equipa adversária */
	    } else if (opcao == 3) {
		System.out.print("Nome do jogador: ");
		String nome = scanner.nextLine();
		
        System.out.print("Posição (GR,D,M,A,): ");
		Posicao posicao = Posicao.valueOf(scanner.nextLine());
        
        System.out.println("Insina o Ano de fundação do Clube:  ");
        int y = scanner.nextInt();
        System.out.println("Insira o Mês de fundação do Clube: ");
        int m = scanner.nextInt();
        System.out.println("Insira o Dia de fundação do Clube: ");
        int d = scanner.nextInt();
        LocalDate DataEntrada = LocalDate.of(y, m, d);
        scanner.nextLine();
        
        System.out.print("\n Inserir a Categoria (R/E/P/NA): ");
        Categoria categoria =  Categoria.valueOf(scanner.nextLine());
		
        Jogador jogador = new Jogador(nome,DataEntrada, categoria, posicao);
	     if (equipaAdversario.size() < 11) {
		equipaAdversario.add(jogador);
	    } else {
		System.out.println("Não se pode adicionar mais jogadores ao plantel da equipa adversária");
	}   
        /* Ver informação do jogo */
	   } else if (opcao == 4) {
		System.out.println("Informação do jogo:");
		System.out.println("Clube da equipa: " + jogo.getClubeEquipa());
		System.out.println("Adversário: " + jogo.getAdversário());
		System.out.println("Resultado clube: " + jogo.getResultadoClube());
		System.out.println("Resultado adversário: " + jogo.getResultadoAdversário());
		System.out.println("Data do jogo: " + jogo.getDataDoJogo());
		System.out.println("Local do jogo: " + jogo.getLocal());
		System.out.println("Tipo de competição: " + jogo.getTipoCompeticao());
		System.out.println("Vencedor: " + jogo.calcularVencedor());
		System.out.println("Jogadores da equipa da Liga: " + equipaLiga);
		System.out.println("Jogadores da equipa adversária: " + equipaAdversario);
	   
        /* Voltar ao menu Principal  */
        } else if (opcao == 5) {
		menuPrincipal();
	   } else {
		System.out.println("Opção inválida");
	} 
}
}
/*-------------------------------------------------------------------------------------------------------------------------------------------------------------------------- */    

/* Menu Jogador */
public static void menuJogador(){
    
    /* Scanner para realizar o input do utilizador */
    Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.print("##-------------------- Menu Jogador --------------------##|\n");
            System.out.print("|---------------------------------------------------------|\n");
            System.out.print("| Opção 1 - Adicionar a ficha de Jogador ao Clube         |\n");
            System.out.print("| Opção 2 - Voltar ao Menu Principal                      |\n");
            System.out.print("|---------------------------------------------------------|\n");
            System.out.print("Digite uma opção: ");

            int opcao = sc.nextInt();
            
            /* Opções a escolher */
            if (opcao == 1) {
                adicionarJogador();
                menuJogador();;
            }if (opcao == 2){
                menuPrincipal();
            }        
}
}
/* Adicionar os dados da ficha de Jogador ao Clube */
 public static void adicionarJogador() {
    Scanner sc = new Scanner(System.in);
        
    System.out.println("Insira o nome do jogador:");
    String nome = String.valueOf(sc.next());
    sc.nextLine();
        
    System.out.println("Insira a data de entrada do jogador (yyyy-mm-dd):");
    LocalDate DataEntrada = LocalDate.parse(sc.nextLine());
        
    System.out.println("Insira a categoria do jogador:");
    Categoria categoria = Categoria.valueOf(sc.nextLine());
        
    System.out.println("Insira a posição do jogador:");
    Posicao posicao = Posicao.valueOf(sc.nextLine());
        
    Jogador j1 = new Jogador(nome, DataEntrada, categoria, posicao);
    jogadores.add(j1);
    
    /* Inserir a ficha do Jogador criado num ficheiro .txt */
    FileWriter writer = null;
                try{
                    writer = new FileWriter("Ficha dos Jogadores",true);
                    writer.write(j1.toString());
                    writer.write(System.lineSeparator());
                    writer.flush();
                }catch(IOException f){
                    f.printStackTrace();
                }finally{
                try{
                    if(writer != null){
                    writer.close();
                                }
                }catch(IOException f){
                    f.printStackTrace();
                            }
                }
}

/*-------------------------------------------------------------------------------------------------------------------------------------------------------------------------- */     

/* Array List dos Jogadores que foram criados no Menu Jogador */
static ArrayList<Jogador> jogadores = new ArrayList<>();

/* Menu Clube */
public static void menuClube(){

        /* Scanner para realizar o input do utilizador */
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.print("##---------------------- Menu Clube --------------------##|\n");
            System.out.print("|---------------------------------------------------------------------------------------|\n");
            System.out.print("| Opção 1 - Inserir nova ficha de jogador no Clube                                      |\n");
            System.out.print("| Opção 2 - Verificar se existe jogador com determinado ID                              |\n");
            System.out.print("| Opção 3 - Obter ficha de jogador com um determinado ID                                |\n");
            System.out.print("| Opção 4 - Inserir lista de jogadores contratados                                      |\n");
            System.out.print("| Opção 5 - Determinar número atual de jogadores de uma posição                         |\n");
            System.out.print("| Opção 6 - Devolver conjunto atual de fichas de jogadores                              |\n");
            System.out.print("| Opção 7 - Devolver conjunto atual de fichas de jogadores, filtrados por categoria     |\n");
            System.out.print("| Opção 8 - Calcular total de salários a pagar em determinado mês                       |\n");
            System.out.print("| Opção 9 - Calcular e apresentar custos trimestrais, semestrais e anuais com salários  |\n");
            System.out.print("| Opção 10 - Guardar lista atual de jogadores num ficheiro de texto                     |\n");
            System.out.print("| Opção 11 - Voltar ao menu Principal                                                   |\n");
            System.out.print("|---------------------------------------------------------------------------------------|\n");
            System.out.print("Digite uma opção: ");


            int opcao = sc.nextInt();
            
            /* Opções a escolher */
            if (opcao == 1) {
                menuJogador();
            } else if (opcao == 2) {
                verificarJogadorPorId(sc);
            } else if (opcao == 3) {
                obterFichaJogadorPorCodigo(sc);
            } else if (opcao == 4) {
                inserirListaJogadoresContratados(sc);
            } else if (opcao == 5) {
                determinarNumeroJogadoresPosicao(sc);
            } else if (opcao == 6) {
                devolverConjuntoFichasJogadores();
            } else if (opcao == 7) {
                devolverConjuntoFichasJogadoresFiltradoPorCategoria(sc);
            } else if (opcao == 8) {
                calcularTotalSalariosMes(sc);
            } else if (opcao == 9) {
                calcularCustosTrimestraisSemestraisAnuais();
            } else if (opcao == 10) {
                guardarListaJogadoresFicheiroTexto();
            } else if (opcao == 11) {
                menuPrincipal();
            } else {
                System.out.println("Opção inválida, tente novamente.");
            }
        }
}

/* Verificar se existe jogador com determinado ID */
private static void verificarJogadorPorId(Scanner sc) {
    System.out.println("Insira o ID do jogador:");
    int id = sc.nextInt();
    boolean encontrado = false;
    for (Jogador jogador : jogadores) {
        if (jogador.getID() == id) {
            System.out.println("Jogador encontrado com o ID " + id);
            encontrado = true;
            break;
        }
    }
    if (!encontrado) {
        System.out.println("Não foi encontrado nenhum jogador com o ID " + id);
    }
}

/* Obter ficha de jogador com um determinado ID */
private static void obterFichaJogadorPorCodigo(Scanner sc) {
    System.out.println("Insira o código do jogador:");
    int codigo = sc.nextInt();
    boolean encontrado = false;
    for (Jogador jogador : jogadores) {
        if (jogador.getID() == codigo) {
            System.out.println(jogador.toString());
            encontrado = true;
            break;
        }
    }
    if (!encontrado) {
        System.out.println("Não foi encontrado nenhum jogador com o código " + codigo);
    }
}

/* Inserir lista de jogadores criados anteriormente */
private static void inserirListaJogadoresContratados(Scanner sc) {
    System.out.println("Insira a quantidade de jogadores a serem contratados:");
    int qtdJogadores = sc.nextInt();
    for (int i = 0; i < qtdJogadores; i++) {
        System.out.println("Insira os dados do jogador " + (i+1) + ":");
        System.out.println("Nome:");
        sc.nextLine();
        String nome = sc.nextLine();
        System.out.println("Data de entrada (yyyy-mm-dd):");
        String dataEntrada = sc.nextLine();
        LocalDate localDate = LocalDate.parse(dataEntrada);
        System.out.println("Posição:");
        String posicao = sc.nextLine();
        System.out.println("Categoria:");
        String categoria = sc.nextLine();
        System.out.println("Salário:");
        double salario = sc.nextDouble();
        System.out.println("Jogos jogados:");
        int jogosJogados = sc.nextInt();
        Jogador jogador = new Jogador(nome, localDate, Categoria.valueOf(categoria), Posicao.valueOf(posicao));
        jogador.setSalario(salario);
        jogador.setJogosJogados(jogosJogados);
        jogadores.add(jogador);
    }
    System.out.println("Lista de jogadores contratados inserida com sucesso.");
}

/* Determinar número atual de jogadores de uma determinada posição  */
private static void determinarNumeroJogadoresPosicao(Scanner sc) {
    System.out.println("Insira a posição:");
    sc.nextLine();
    String posicao = sc.nextLine();
    int contador = 0;
    for (Jogador jogador : jogadores) {
        if (jogador.getPosicao().name().equalsIgnoreCase(posicao)) {
            contador++;
        }
    }
    System.out.println("Existem " + contador + " jogadores na posição " + posicao);
}

/* Devolver o conteúdo da Ficha dos Jogadores */
private static void devolverConjuntoFichasJogadores() {
    for (Jogador jog : jogadores) {
        System.out.println(jog.toString());
    }
}

/* Devolver o conteúdo da Fichas de Jogadores, filtrados por categoria */
private static void devolverConjuntoFichasJogadoresFiltradoPorCategoria(Scanner sc) {
    System.out.println("Insira a categoria:");
    sc.nextLine();
    String categoria = sc.nextLine();
    for (Jogador jogador : jogadores) {
        if (jogador.getCategoria().name().equalsIgnoreCase(categoria)) {
            System.out.println(jogador.toString());
        }
    }
}

/* Calcular total de salários a pagar num determinado mês   */
private static void calcularTotalSalariosMes(Scanner sc) {
    System.out.println("Insira o mês (mm):");
    int mes = sc.nextInt();
    double total = 0;
    for (Jogador jogador : jogadores) {
            total += jogador.getVencimento();
        }
        System.out.println("O total de salários a pagar no mês " + mes + " é: " + total);
    }

/*Calcular e apresentar custos trimestrais, semestrais e anuais com salários */
private static void calcularCustosTrimestraisSemestraisAnuais() {
    double totalTrimestral = 0;
    double totalSemestral = 0;
    double totalAnual = 0;
    for (Jogador jogador : jogadores) {
        totalTrimestral += jogador.getVencimento() * 3; /* <---- Trimestrais */
        totalSemestral += jogador.getVencimento() * 6;  /* <---- Semestrais */ 
        totalAnual += jogador.getVencimento() * 12;     /* <---- Anuais */
    }
    System.out.println("Custo trimestral: " + totalTrimestral);
    System.out.println("Custo semestral: " + totalSemestral);
    System.out.println("Custo anual: " + totalAnual);
}

/*Guardar lista de Jogadores num ficheiro .txt */
private static void guardarListaJogadoresFicheiroTexto() {
    try {
        FileWriter writer = new FileWriter("jogadores.txt");
        for (Jogador jogador : jogadores) {
            writer.write(jogador.toString() + "\n");
        }
        writer.close();
        System.out.println("Lista de jogadores guardada com sucesso no ficheiro jogadores.txt");
    } catch (IOException e) {
        System.out.println("Ocorreu um erro ao guardar a lista de jogadores no ficheiro.");
        e.printStackTrace();
    }
}
}

