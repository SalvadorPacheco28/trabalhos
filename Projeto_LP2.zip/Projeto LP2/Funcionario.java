import java.time.LocalDate;
import java.util.ArrayList;

public class Funcionario extends Clube {  /* Funcionário Extende a Classe Clube */

    /* Construtor */
    public Funcionario(String Nome, LocalDate dataDeFundação, String Concelho, ArrayList<Jogador> clube, int ano,
            int mês, int dia) {
        super(Nome, dataDeFundação, Concelho, clube, ano, mês, dia);
        //TODO Auto-generated constructor stub
    }
}
