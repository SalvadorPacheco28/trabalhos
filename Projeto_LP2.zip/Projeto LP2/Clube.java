import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Clube {
    private String nome;
    private LocalDate dataFundacao;
    private String concelho;
    private ArrayList<Jogador> jogadores;

    /* Construtor */
    public Clube(String nome, LocalDate dataFundacao, String concelho, int ano, int mês, int dia) {
        if(nome == null){
            this.nome = "";         ///////////////////
        }                           //  Verificação //
        else{                       /////////////////
            this.nome = nome;
        }
        if(dataFundacao != null){
            this.dataFundacao = dataFundacao;}
        else{
            this.dataFundacao = LocalDate.now();
        }
        if(concelho == null){
            this.concelho = "";
        }
        else{
            this.concelho = concelho;
        }
        this.jogadores = new ArrayList<Jogador>();
    }
/*----------------------------------------------- /Sets e Gets/ ------------------------------------------------------- */    
    public void setNome(String Nome){           
        this.nome = Nome;
    }
    public String getNome(){
        return nome;
    }                                                   
    public void setDateDeFundação(LocalDate dataFundacao){
        this.dataFundacao = dataFundacao;
    }
    public LocalDate getDatadeFundação(){
        return dataFundacao;
    }
    public void setConcelho(String concelho){
        this.concelho = concelho;
    }
    public String getConcelho(){
        return concelho;
    }
/*----------------------------------------------- /Sets e Gets/ ------------------------------------------------------- */


public void inserirJogador(Jogador jogador) {
    jogadores.add(jogador);
}

public boolean existeJogador(int id) {
    for (Jogador jogador : jogadores) {
        if (jogador.getID() == id) {
            return true;
        }
    }
    return false;
}
public Jogador obterJogadorPorId(int id) {
    for (Jogador jogador : jogadores) {
        if (jogador.getID() == id) {
            return jogador;
        }
    }
    return null;
}
public void inserirJogadores(List<Jogador> novosJogadores) {
    jogadores.addAll(novosJogadores);
}
public int contarJogadoresPorPosicao(Posicao posicao) {
    int contador = 0;
    for (Jogador jogador : jogadores) {
        if (jogador.getPosicao().equals(posicao)) {
            contador++;
        }
    }
    return contador;
}
public List<Jogador> obterJogadores() {
    return jogadores;
}
public List<Jogador> obterJogadoresPorCategoria(Categoria categoria) {
    List<Jogador> jogadoresFiltrados = new ArrayList<Jogador>();
    for (Jogador jogador : jogadores) {
        if (jogador.getCategoria().equals(categoria)) {
            jogadoresFiltrados.add(jogador);
        }
    }
    return jogadoresFiltrados;
}
public double calcularSalariosMensais(String mes) {
    double salarios = 0;
    for (Jogador jogador : jogadores) {
        salarios += jogador.getSalario();
    }
    return salarios;
}
public double calcularCustosTrimestrais() {
    return calcularSalariosMensais("jan")*3;
}

public double calcularCustosSemestrais() {
    return calcularSalariosMensais("jan")*6;
}

public double calcularCustosAnuais() {
    return calcularSalariosMensais("jan")*12;
}
public void guardarJogadoresEmFicheiro(String caminhoFicheiro) {
    try {
        FileOutputStream fos = new FileOutputStream(caminhoFicheiro);
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(jogadores);
        oos.close();
        fos.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
}

public void carregarJogadores() {
    try {
        FileInputStream fis = new FileInputStream("jogadores.dat");
        ObjectInputStream ois = new ObjectInputStream(fis);
        jogadores = (ArrayList<Jogador>) ois.readObject();
        ois.close();
        fis.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
}
}
