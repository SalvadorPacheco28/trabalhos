/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab07_res;

/**
 *
 * @author Pat
 */
public class Lab07_Res {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

//        CellPhone cl = new CellPhone("123456789");
//        cl.openApp("Snsake");
        SmartPhone sp = new SmartPhone("123", 2);
//        sp.openApp("Calculadora");
//        sp.openApp("SMS");
//        sp.showOpenApps();
//        sp.closeApp("SMS");
//        sp.showOpenApps();
//        sp.closeAllOpenApps();
//        sp.showOpenApps();
//        sp.installApp("aaa");
//        sp.showPhoneApps();
//        sp.openApp("aaa");
//        sp.showOpenApps();
        sp.showPhoneApps();
        sp.installApp("aaa");
        sp.showPhoneApps();
        sp.uninstallApp("SMS");
        sp.showPhoneApps();

    }

}
