/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab07_res;

/**
 *
 * @author Pat
 */
public interface ITelephone {

    public void dial(String number);

    public void ringging();

    public void endCall();

    public String setNumber();

    public boolean answerCall(String number);

    public boolean call(String number);

}
