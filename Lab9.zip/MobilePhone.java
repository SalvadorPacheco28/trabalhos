/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab07_res;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Pat
 */
public abstract class MobilePhone extends Telephone {

    private String numberOnDisplay;
    private ArrayList<String> appList;
    private int maxSimultaneousApps;
    private ArrayList<String> openAppList;

    public MobilePhone(String myNumber, int maxSimultaneousApps) {
        super(myNumber);
        numberOnDisplay = "";
        if (maxSimultaneousApps > 0) {
            this.maxSimultaneousApps = maxSimultaneousApps;
        } else {
            this.maxSimultaneousApps = 50;
        }
        appList = new ArrayList<>();
        openAppList = new ArrayList<>();
        appList.add("Calculadora");
        appList.add("Contactos");
        appList.add("SMS");

    }

    @Override
    public void dial(String number) {
        this.numberOnDisplay=number;
        System.out.println(numberOnDisplay);
    }

    public void clearNumber() {
        numberOnDisplay = "";
    }

    @Override
    public boolean answerCall(String number) {

        char answer;
        Scanner scanner = new Scanner(System.in);
        do {
            System.out.println("Chamada do número " + number + " Atender? [S|N]");
            try {
                answer = scanner.nextLine().toUpperCase().charAt(0);
            } catch (Exception e) {
                answer = ' ';
            }

        } while (answer != 'S' && answer != 'N');
        if (answer == 'S') {
            System.out.println("Em chamada com o número " + number);
            setIsBusy(true);

            return true;
        } else {
            setIsBusy(false);
            return false;
        }
    }

    public abstract void openApp(String app);

    public abstract void closeApp(String app);

    public String getNumberOnDisplay() {
        return numberOnDisplay;
    }

    public ArrayList<String> getAppList() {
        return appList;
    }

    public int getMaxSimultaneousApps() {
        return maxSimultaneousApps;
    }

    public ArrayList<String> getOpenAppsList() {
        return openAppList;
    }

}
