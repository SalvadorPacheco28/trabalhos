/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab07_res;

import java.util.Random;

/**
 *
 * @author Pat
 */
public abstract class Telephone implements ITelephone {

    private String myNumber;
    private boolean isBusy;
    private boolean onCall;

    public Telephone(String myNumber) {

        if (myNumber.length() == 9) {
            try {
                this.myNumber = String.valueOf(myNumber);
                this.myNumber = myNumber;
            } catch (Exception e) {
                this.myNumber = setNumber();
            }
        } else {
            this.myNumber = setNumber();
        }

        isBusy = false;
        onCall = false;
        //tune = "Trimm Trimm";

    }

    public String setNumber() {
        int n;
        Random rnd = new Random(System.currentTimeMillis());
        n = rnd.nextInt(1000000000) + 100000000;
        return String.valueOf(n);
    }

    public abstract void dial(String number);

    public void ringging() {
        if (!isBusy) {

            isBusy = true;
            onCall = answerCall(setNumber());
        }
    }

    public abstract boolean answerCall(String number);

    public void endCall() {
        if (onCall) {
            onCall = false;
            System.out.println("Fim de chamada");
        }
    }

    public boolean call(String number) {

        try {
            if (number.isEmpty()) {
                throw new IllegalArgumentException();
            }
            if (!this.myNumber.equals(number)) {
                System.out.println("A ligar para o nº" + number);
                for (int i = 0; i < 10; i++) {
                    System.out.printf(". ");
                    Thread.sleep(500);
                }
                onCall = true;
                isBusy = true;
                return true;
            } else {
                System.out.println("O nº está ocupado");
            }
        } catch (Exception e) {
            System.out.println("Nº inválido");
        }
        isBusy = false;
        onCall = false;
        return false;
    }

    public String getMyNumber() {
        return myNumber;
    }

    public void setMyNumber(String myNumber) {
        this.myNumber = myNumber;
    }

    public boolean isIsBusy() {
        return isBusy;
    }

    public void setIsBusy(boolean isBusy) {
        this.isBusy = isBusy;
    }

    public boolean isOnCall() {
        return onCall;
    }

    public void setOnCall(boolean onCall) {
        this.onCall = onCall;
    }

}
