/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab07_res;

import java.util.ArrayList;

/**
 *
 * @author Pat
 */
public class SmartPhone extends MobilePhone {

    public SmartPhone(String myNumber, int maxSimultaneousApps) {
        super(myNumber, maxSimultaneousApps);

    }

    @Override
    public void openApp(String app) {

        if (app != null && !app.equals("")) {

            if (getAppList().indexOf(app) != -1) {
                if (getOpenAppsList().indexOf(app) == -1) {
                    if (getOpenAppsList().size() < getMaxSimultaneousApps()) {
                        getOpenAppsList().add(app);
                        System.out.println("Aberta a app " + app);
                    } else {
                        System.out.println("Máximo de apps abertas");
                    }

                } else {
                    System.out.println("App " + app + " já aberta SmartPhone");
                }
            } else {
                System.out.println("App " + app + " não existe no SmartPhone");
            }
        }
    }

    @Override
    public void closeApp(String app) {
        int i;
        if (getOpenAppsList().indexOf(app) != -1) {
            getOpenAppsList().remove(app);
        }
    }

    public void showOpenApps() {
        for (String s : getOpenAppsList()) {
            System.out.println(s);
        }
    }

    public void showPhoneApps() {
        for (String s : getAppList()) {
            System.out.println(s);
        }
    }

    public void installApp(String app) {
        if (app != null && !app.equals("")) {
            if (getAppList().indexOf(app) == -1) {
                getAppList().add(app);
            }
        }
    }

    public void uninstallApp(String app) {
        if (app != null && !app.equals("")) {
            if (getAppList().indexOf(app) != -1) {
                getAppList().remove(app);
            }
        }
    }

}
