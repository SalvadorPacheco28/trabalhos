/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab07_res;

/**
 *
 * @author Pat
 */
public class CellPhone extends MobilePhone {

    public CellPhone(String myNumber) {
        super(myNumber, 1);
        getAppList().add("Snake");

    }

    @Override
    public void closeApp(String app) {
        try {
            if (app != null && getOpenAppsList().get(0).equals(app)) {
                getOpenAppsList().remove(0);
            }
        } catch (Exception e) {
        }
    }

    public void closeApp() {
        if (getOpenAppsList().size() == 1) {
            getOpenAppsList().remove(0);
        }
    }

    @Override
    public void openApp(String app) {
        for (String s : getAppList()) {
            if (s.contains(app)) {
                closeApp();
                getAppList().add(app);
            }
            showActiveApp();
        }

    }

    public void showActiveApp() {
        if (getOpenAppsList().size() == 1) {
            System.out.println(getOpenAppsList().get(0));
        }
    }

}
